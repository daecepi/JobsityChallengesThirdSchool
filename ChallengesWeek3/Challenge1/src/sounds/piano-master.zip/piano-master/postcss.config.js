module.exports = { 
  plugins: {
    'autoprefixer': {},
    'rucksack-css': {},
    'lost': {},
    'postcss-font-magician': {},
    'cssnano': {}
  }
};
